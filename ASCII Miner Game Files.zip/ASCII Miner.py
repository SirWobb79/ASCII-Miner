import os
import time

version = "1.3.1"
update_log = "(16th Oct 2022) Autosave exists! Every 750 gameticks, the game will save itself."

print(f"<ASCII Miner {version}>\n\nW A S D: Move\nU: Upgrade\nR: Reset map\nP: Prestige\nSHOP: Go to shop menu\nSAVE: Save game\nLOAD: Load saved state\n\nYou: \033[1;32;40m>\033[1;37;40m\nBlocks: @\nNothing: .\n\nUpdates: {update_log}")

mine = [["@"for a in range(34)]for b in range(20)]

player = "\033[1;32;40m>\033[1;37;40m"
empty = "."

x = 0
y = 0

cash = 0
cashadd = 1
income = cashadd
pay = 20
price = pay
upgrade = 1

prestige = 0
xp = 0
levelup = 1000
tokens = 0

idle1 = 0
idle2 = 0
idle3 = 0
preidle = 0

idlecount1 = 0
idlecount2 = 0
idlecount3 = 0
preidlecount = 0

priceidle1 = 50
priceidle2 = 250
priceidle3 = 7500
prepriceidle = 15000

idletotal = 0

limit = 750
autosave = limit

mine[y][x] = player

game_start = input("\nPress ENTER to start\n")
 
game = True
while game == True:
    
    os.system("cls" if os.name == "nt" else "clear")
    
    print(f"You earn \033[1;31;40m${income}\033[1;37;40m per block\nYou have \033[1;32;40m${cash}\033[1;37;40m \nUpgrade \033[1;33;40m{upgrade}\033[1;37;40m is \033[1;34;40m${price}\033[1;37;40m\nYou are on Prestige \033[1;35;40m{prestige}\033[1;37;40m\nYou have \033[1;36;40m{tokens} (₩) \033[1;37;40mprestige tokens\nXP: \033[1;32;40m{xp}\033[1;37;40m | You need \033[1;33;40m{levelup}\033[1;37;40m XP to prestige\nYou make \033[1;32;40m${idletotal}\033[1;37;40m automatically\n\033[1;34;40m{autosave}\033[1;37;40m game ticks until next autosave\n--------------------------------------------------------------Mine-")
    
    for i in mine:
        print(" ".join(i))
        
    action = input(">")
    
    if action == "s":
        y += 1
        if mine[y][x] == empty:
            y -= 1
            mine[y][x] = empty
            y += 1
            mine[y][x] = "\033[1;32;40mv\033[1;37;40m"
        else:
            y -= 1
            mine[y][x] = empty
            y += 1
            mine[y][x] = "\033[1;32;40mv\033[1;37;40m"
            cash += income
            xp += 1
        
    elif action == "a":
        x -= 1
        if mine[y][x] == empty:
            x += 1
            mine[y][x] = empty
            x -= 1
            mine[y][x] = "\033[1;32;40m<\033[1;37;40m"
        else:
            x += 1
            mine[y][x] = empty
            x -= 1
            mine[y][x] = "\033[1;32;40m<\033[1;37;40m"
            cash += income
            xp += 1
        
    elif action == "d":
        x += 1
        if mine[y][x] == empty:
            x -= 1
            mine[y][x] = empty
            x += 1
            mine[y][x] = "\033[1;32;40m>\033[1;37;40m"
        else:
            x -= 1
            mine[y][x] = empty
            x += 1
            mine[y][x] = "\033[1;32;40m>\033[1;37;40m"
            cash += income
            xp += 1
    
    elif action == "w":
        y -= 1
        if mine[y][x] == empty:
            y += 1
            mine[y][x] = empty
            y -= 1
            mine[y][x] = "\033[1;32;40m^\033[1;37;40m"
        else:
            y += 1
            mine[y][x] = empty
            y -= 1
            mine[y][x] = "\033[1;32;40m^\033[1;37;40m"
            cash += income
            xp += 1
            
    elif action == "u":
        if cash >= price:
            upgrade += 1
            cash -= price
            pay *= 3
            income *= 2
            price = pay
    
    elif action == "r":
        mine = [["@"for a in range(34)]for b in range(20)]
        x = 0
        y = 0
        mine[y][x] = player
        print("Map resetting...")
        time.sleep(3)
        
    elif action == "p":
        advance = input("Are you sure you want to prestige? You cash becomes tokens for\npremium upgrades, but all normal things become their standard.\n(Y/N)\n>")
        if advance == "y":
            if xp >= levelup:
                mine = [["@"for a in range(15)]for b in range(15)]

                player = "\033[1;32;40m>\033[1;37;40m"
                empty = "."

                x = 7
                y = 0
                
                cashadd = 1
                income = cashadd
                pay = 20
                price = pay
                upgrade = 1
                prestige += 1
                xp = 0
                levelup *= 5
                tokens += cash
                cash = 0
    
                idle1 = 0
                idle2 = 0
                idle3 = 0

                idlecount1 = 0
                idlecount2 = 0
                idlecount3 = 0

                priceidle1 = 50
                priceidle2 = 250
                priceidle3 = 7500
        
                idletotal = 0

                mine[y][x] = player
            else:
                print(f"Oops. It appears that you do not have enough XP. You need {levelup} XP.")
                time.sleep(5)
                os.system("cls" if os.name == "nt" else "clear")

    elif action == "shop":
        
        os.system("cls" if os.name == "nt" else "clear")
        
        print(f"<ASCII Miner {version}>\n\n1: An average miner (You have {idlecount1}, adds $1) ${priceidle1}\n\n2: Strong miner (You have {idlecount2}, adds $5) ${priceidle2}\n\n3: Drill (You have {idlecount3}, adds $25) ${priceidle3}\n\n\033[1;36;40mP: Time Speeder 2000 (You have {preidlecount}, multiplies by 2) ₩{prepriceidle} \033[1;37;40m\n\nYou have \033[1;32;40m${cash}\033[1;37;40m and \033[1;36;40m₩{tokens} \033[1;37;40m\n")
        
        buy = input("What would you like to buy? ")
        
        if buy == "1":
            if cash >= priceidle1:
                idle1 += 1
                cash -= priceidle1
                priceidle1 *= 2
                idlecount1 += 1
                idletotal += 1
            
        if buy == "2":
            if cash >= priceidle2:
                idle2 += 5
                cash -= priceidle2
                priceidle2 *= 2
                idlecount2 += 1
                idletotal += 5
            
        if buy == "3":
            if cash >= priceidle3:
                idle3 += 25
                cash -= priceidle3
                priceidle3 *= 2
                idlecount3 += 1
                idletotal += 25
                
        if buy == "p":
            if tokens >= prepriceidle:
                preidle *= 2
                tokens -= prepriceidle
                prepriceidle *= 3
                preidlecount += 1
                idletotal *= 2
                
    elif action == "save" or autosave == 0:
        file_cash = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/cash.txt", "w")
        file_cashadd = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/cashadd.txt", "w")
        file_income = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/income.txt", "w")
        file_pay = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/pay.txt", "w")
        file_price = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/price.txt", "w")
        file_upgrade = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/upgrade.txt", "w")

        file_prestige = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/prestige.txt", "w")
        file_xp = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/xp.txt", "w")
        file_levelup = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/levelup.txt", "w")
        file_tokens = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/tokens.txt", "w")

        file_idle1 = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/idle1.txt", "w")
        file_idle2 = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/idle2.txt", "w")
        file_idle3 = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/idle3.txt", "w")
        file_preidle = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/preidle.txt", "w")

        file_idlecount1 = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/idlecount1.txt", "w")
        file_idlecount2 = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/idlecount2.txt", "w")
        file_idlecount3 = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/idlecount3.txt", "w")
        file_preidlecount = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/preidlecount.txt", "w")

        file_priceidle1 = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/priceidle1.txt", "w")
        file_priceidle2 = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/priceidle2.txt", "w")
        file_priceidle3 = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/priceidle3.txt", "w")
        file_prepriceidle = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/prepriceidle.txt", "w")

        file_idletotal = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/idletotal.txt", "w")
        
        with file_cash as save:
            save.write(str(cash))
        with file_cashadd as save:
            save.write(str(cashadd))
        with file_income as save:
            save.write(str(income))
        with file_pay as save:
            save.write(str(pay))
        with file_price as save:
            save.write(str(price))
        with file_upgrade as save:
            save.write(str(upgrade))
        
        with file_prestige as save:
            save.write(str(prestige))
        with file_xp as save:
            save.write(str(xp))
        with file_levelup as save:
            save.write(str(levelup))
        with file_tokens as save:
            save.write(str(tokens))
        
        with file_idle1 as save:
            save.write(str(idle1))
        with file_idle2 as save:
            save.write(str(idle2))
        with file_idle3 as save:
            save.write(str(idle3))
        with file_preidle as save:
            save.write(str(preidle))
        
        with file_idlecount1 as save:
            save.write(str(idlecount1))
        with file_idlecount2 as save:
            save.write(str(idlecount2))
        with file_idlecount3 as save:
            save.write(str(idlecount3))
        with file_preidlecount as save:
            save.write(str(preidlecount))
        
        with file_priceidle1 as save:
            save.write(str(priceidle1))
        with file_priceidle2 as save:
            save.write(str(priceidle2))
        with file_priceidle3 as save:
            save.write(str(priceidle3))
        with file_prepriceidle as save:
            save.write(str(prepriceidle))
        
        with file_idletotal as save:
            save.write(str(idletotal))
            
        file_cash.close()
        file_cashadd.close()
        file_income.close()
        file_pay.close()
        file_price.close()
        file_upgrade.close()
        
        file_prestige.close()
        file_xp.close()
        file_levelup.close()
        file_tokens.close()
        
        file_idle1.close()
        file_idle2.close()
        file_idle3.close()
        file_preidle.close()
        
        file_idlecount1.close()
        file_idlecount2.close()
        file_idlecount3.close()
        file_preidlecount.close()
        
        file_priceidle1.close()
        file_priceidle2.close()
        file_priceidle3.close()
        file_prepriceidle.close()
        
        file_idletotal.close()
        
        autosave = limit
        
    elif action == "load":
        file_cash = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/cash.txt", "r")
        cash = int(file_cash.read())
        file_cashadd = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/cashadd.txt", "r")
        cashadd = int(file_cashadd.read())
        file_income = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/income.txt", "r")
        income = int(file_income.read())
        file_pay = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/pay.txt", "r")
        pay = int(file_pay.read())
        file_price = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/price.txt", "r")
        price = int(file_price.read())
        file_upgrade = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/upgrade.txt", "r")
        upgrade = int(file_upgrade.read())

        file_prestige = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/prestige.txt", "r")
        prestige = int(file_prestige.read())
        file_xp = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/xp.txt", "r")
        xp = int(file_xp.read())
        file_levelup = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/levelup.txt", "r")
        levelup = int(file_levelup.read())
        file_tokens = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/tokens.txt", "r")
        tokens = int(file_tokens.read())

        file_idle1 = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/idle1.txt", "r")
        idle1 = int(file_idle1.read())
        file_idle2 = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/idle2.txt", "r")
        idle2 = int(file_idle2.read())
        file_idle3 = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/idle3.txt", "r")
        idle3 = int(file_idle3.read())
        file_preidle = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/preidle.txt", "r")
        preidle = int(file_preidle.read())

        file_idlecount1 = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/idlecount1.txt", "r")
        idlecount1 = int(file_idlecount1.read())
        file_idlecount2 = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/idlecount2.txt", "r")
        idlecount2 = int(file_idlecount2.read())
        file_idlecount3 = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/idlecount3.txt", "r")
        idlecount3 = int(file_idlecount3.read())
        file_preidlecount = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/preidlecount.txt", "r")
        preidlecount = int(file_preidlecount.read())

        file_priceidle1 = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/priceidle1.txt", "r")
        priceidle1 = int(file_priceidle1.read())
        file_priceidle2 = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/priceidle2.txt", "r")
        priceidle2 = int(file_priceidle2.read())
        file_priceidle3 = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/priceidle3.txt", "r")
        priceidle3 = int(file_priceidle3.read())
        file_prepriceidle = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/prepriceidle.txt", "r")
        prepriceidle = int(file_prepriceidle.read())

        file_idletotal = open("/storage/emulated/0/ASCII Miner Game Files/Save Data/idletotal.txt", "r")
        idletotal = int(file_idletotal.read())
        
    cash += idletotal
    autosave -= 1